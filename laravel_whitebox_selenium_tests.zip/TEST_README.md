# Bộ test cho Laravel Classroom Management

## Cấu trúc

```text
tests/
├── Feature/
│   ├── AuthTest.php
│   ├── RoomManagementTest.php
│   ├── CourseManagementTest.php
│   └── BookingRequestTest.php
│
└── Selenium/
    ├── selenium_login.py
    ├── selenium_room.py
    └── selenium_booking_request.py
```

## Chạy white-box test Laravel

Copy thư mục `tests/Feature` vào project Laravel, sau đó chạy:

```bash
php artisan test
```

Chạy từng file:

```bash
php artisan test --filter=AuthTest
php artisan test --filter=RoomManagementTest
php artisan test --filter=CourseManagementTest
php artisan test --filter=BookingRequestTest
```

## Chạy Selenium UI test

Cài Selenium:

```bash
pip install selenium
```

Chạy Laravel server:

```bash
php artisan serve
```

Chạy từng file:

```bash
python tests/Selenium/selenium_login.py
python tests/Selenium/selenium_room.py
python tests/Selenium/selenium_booking_request.py
```

Mặc định Selenium dùng:

```text
BASE_URL=http://127.0.0.1:8000
ADMIN_USERNAME=admin
ADMIN_PASSWORD=password
USER_USERNAME=giaovien1
USER_PASSWORD=password
```

Có thể đổi bằng biến môi trường nếu tài khoản trong database khác.

## Lưu ý

- PHPUnit test có dùng `RefreshDatabase`, nên chạy trên database test riêng hoặc SQLite testing để tránh ảnh hưởng dữ liệu thật.
- Selenium test cần database đã có tài khoản admin/user. File `selenium_booking_request.py` cần có ít nhất 1 phòng và 1 môn học để form chọn được dữ liệu.
